package com.example.statistique_progress

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
